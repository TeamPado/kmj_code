using UnityEngine;

namespace DarkPixelRPGUI.Scripts
{
    public class ApplicationExit : MonoBehaviour
    {
        public void Exit()
        {
            Application.Quit();
        }
    }
}